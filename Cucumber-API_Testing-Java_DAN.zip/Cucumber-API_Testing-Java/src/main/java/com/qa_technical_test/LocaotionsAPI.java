package com.qa_technical_test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.io.IOUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.fluent.Form;
import org.apache.http.client.fluent.Request;
import org.apache.http.client.fluent.Response;
import org.apache.http.entity.ContentType;
import org.apache.http.protocol.HTTP;
import org.apache.http.protocol.ResponseContent;

import com.jayway.jsonpath.JsonPath;
import com.qa_technical_test.constants.Endpoints;
import com.qa_technical_test.constants.TestData;

import junit.framework.Assert;

public class LocaotionsAPI {

	public static String APIURL=null;
	public static HashMap<String,String> result=null;
    public static final Charset UTF_8 = Charset.forName("UTF-8");

	public void requestURL(String baseURL,String path){
	
		APIURL= baseURL+path;
		System.out.println("BaseURL--->"+APIURL);
	} 
/**
 * @Method Name locationsAPI
 * @Description : locationsAPI 
 * @return HashMap   
 * @throws ClientProtocolException
 * @throws IOException
 */
 
 
	public HashMap<String,String> getLocaotionsAPI( )  {
		HashMap<String,String> result=new HashMap<String,String>();
		try {
				 
			HttpResponse response=Request.Get(APIURL)
					 .addHeader("X-IBM-Client-Id", "f8910348-843a-407e-b5a4-078d3b3c2943")
					 .addHeader("Accept", "application/json")
			         .execute().returnResponse();
			
		  HttpEntity entity=response.getEntity();
	     System.out.println("String reponse --->"+ response.getStatusLine().getStatusCode()  );
 
	     String theString = IOUtils.toString(response.getEntity().getContent(), StandardCharsets.UTF_8); 
	     System.out.println("String reponse --->"+ theString);

	     result.put("HTTPCODE",  String.valueOf(response.getStatusLine().getStatusCode()));
	     result.put("HTTPResponse",IOUtils.toString(response.getEntity().getContent(), StandardCharsets.UTF_8));

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception e" );

		}
		return result;
	}
 
	 

@SuppressWarnings("deprecation")
public void verifyHttpCode ( String actualresponsecode,  String expresponsecode){
	
	Assert.assertEquals(actualresponsecode, expresponsecode);
	System.out.println("Assertion validated...");
 }
 
	public static void main(String[] args) throws ClientProtocolException, IOException {

 
	}

}
