package com.qa_technical_test.constants;

public class Endpoints {

	public   final static String  BASEURL="https://srvapigdvlsu01.mx.santanderus.dev.corp";
	
	//Song
	public   final static String  getlocations="/coe/sb/locations?distance=1&findType=all&address=36+marlboro+quincy+ma";
	 
    public final static String httpcode200="200";
	
}
