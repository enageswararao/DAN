package com.qa_technical_test.constants;

public class TestData {

	
	public static final String createVideoJSON="{ \"artist\": \"Lady verru\", \"song\": \"Poker face\", \"publishDate\": \"2017-09-01\" }";
	public static final String createPlaylistJSON="{\"desc\": \"My first playlist.\", \"title\": \"My List\"}";
 
	
 
}
